﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;

namespace WebApplication2.Pages.DrinkLogs
{
    public class DeleteModel : PageModel
    {
        private readonly WebApplication2.Data.ApplicationDbContext _context;

        public DeleteModel(WebApplication2.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
      public DrinkLog DrinkLog { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.DrinkLog == null)
            {
                return NotFound();
            }

            var drinklog = await _context.DrinkLog.FirstOrDefaultAsync(m => m.Id == id);

            if (drinklog == null)
            {
                return NotFound();
            }
            else 
            {
                DrinkLog = drinklog;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.DrinkLog == null)
            {
                return NotFound();
            }
            var drinklog = await _context.DrinkLog.FindAsync(id);

            if (drinklog != null)
            {
                DrinkLog = drinklog;
                _context.DrinkLog.Remove(DrinkLog);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
